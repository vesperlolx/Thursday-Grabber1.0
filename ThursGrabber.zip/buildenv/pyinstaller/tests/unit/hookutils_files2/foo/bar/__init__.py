# Print something to stdout
print("Hello world!")
