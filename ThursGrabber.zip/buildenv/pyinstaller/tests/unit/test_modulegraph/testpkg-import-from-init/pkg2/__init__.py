""" pkg2.__init__ """
