""" pkg.subpkg.compat """

X, Y = 1, 2
